;10/18/23 Monitor for Z1RCC
;Adopted from RIZMon
;512K starts from 0x0
CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg
;Z180 registers
CNTLA0	equ 0C0h		;Z180 ASCI control reg A0
CNTLB0	equ 0C2h		;Z180 ASCI Control reg B0
RxData  	equ 0C8h        	; Z180 Chan 0 receive register
TxData  	equ 0C6h        	; Z180 Chan 0 transmit register
RxStat  	equ 0C4h       	; Z180 Chan 0 receiver status/control register
CBR	equ 0f8h		;MMU common base register
CBAR	equ 0fah		;MMU common/bank area reg
BBR	equ 0f9h		;MMU bank base register
ICR	equ 3Fh		; I/O control register
	org 0a000h


	org 0b400h
	jp start		;boot table
	jp wboot		;warm boot
	jp cstat		;console input status
	jp cin		;console input
	jp cout		;console output
; variable area
testseed: ds 2		; RAM test seed value
addr3116	ds 2		; high address for Intel Hex format 4
RDsector	ds 1		; current RAM disk sector
RDtrack	ds 1		; current RAM disk track 
RDaddr	ds 2		; current RAM disk address 
sectoff	ds 2		; offset from a track & sector
readbsysav	ds 1	;scratch memory for readbsy routine
fUpload	ds 1		;extended addressing flag
fSecRange	ds 1		;ROMWBW inner loop
wbwbank	ds 1		;ROMWBW bank value
	ds 1		;ROMWBW storage sector number
;currbank	ds 1		;current bank for file load operation, updated with Intel Hex
			;  extended addressing command

start:
	ld a,80h		;common at top 32K, banked at bottom 32K
	out0 (CBAR),a
	ld sp,0b400h	;set stack just below the program
;I/O registier is already relocated to 0xC0 by the loader
;	ld a,0c0h		;relocate I/O register to 0xC0
;	out0 (ICR),a
	ld a,64h		;transmit, receive enable, 8-bit 1 stop
	out0 (CNTLA0),a
	xor a
	out0 (CNTLB0),a	;divided by 160, 38400 with 12.288MHz clock
	ld hl,signon$
	call strout
	ld a,080h		;turn off CPLD ROM
	out (1fh),a
	call readbsy	;;8 wait until busy flag is cleared
	jr nz,NoCF	;readbsy return Z flag clear if timed out
	ld a,0e0h		;;8 set up LBA mode
	out (CF2427),a	;;8
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8

	xor a
	ld (sectoff),a	;initialize (clear) sector offset
	ld (sectoff+1),a
	jr nxt1
NoCF:
	ld hl,NoCF$
	call strout
nxt1:
	ld hl,251		; initialize RAM test seed value
	ld (testseed),hl	; save it
wboot:
clrRx:
	call cstat
	jr z,CMD
	call cin
	jr clrRx
CMD:
	ld hl,prompt$
	call strout
CMDLP1:
        	call cinq
	cp ':'		; Is this Intel load file?
	jp z,initload
	cp 0ah		; ignore line feed
	jr z,CMDLP1
	cp 0dh		; carriage return get a new prompt
	jr z,CMD
	call cout		; echo character
        	and 5Fh
	cp 'H'		; help command
	jp z,help
        	CP A,'D'
        	JP Z,MEMDMP
        	CP A,'E'
       	JP Z,EDMEM
	cp a,'I'		; read data from specified I/O port in page 0
	jp z,INPORT
	cp a,'O'		; write data to specified I/O port in page 0
	jp z,OUTPORT
	cp a,'L'		; list memory as Intel Hex format
	jp z,LISTHEX
        	CP A,'G'
        	JP Z,go
	cp a,'R'		; read a CF sector
	jp z,readCF
	cp a,'Z'		; fill memory with zeros
	jp z,fillZ
	cp a,'F'		; fill memory with ff
	jp z,fillF
	cp a,'C'		; Copy to CF	
	jp z,copyCF
	cp a,'T'		; testing RAM 
	jp z,testRAM
	cp 'B'		; boot CPM
	jp z,BootCPM
	cp 'X'		; clear RAMdisk directory at 0x80000
	jp z,format
what:
        	ld hl,what$
        	CALL strout
        	jr CMD
abort:
	ld hl,abort$	; print command not executed
	call strout
	jr CMD
readbsy:
; spin on CF status busy bit
;Z flag set (equal) if CF not busy
;Z flag reset (not equal) if timed out
	ld (readbsysav),a	;save reg A
	push de
	push bc
	ld de,0		;set a timeout limit
	ld bc,02		;adjust timeout for 9.2MHz Z1RCC
readbsy1
	inc de
	ld a,d
	or e
	jr nz,moreRdBsy
	dec c
	jr nz,moreRdBsy
	xor a
	inc a		;clear Z flag
	pop bc
	pop de
	ld a,(readbsysav)	;restore regA, but not status flags
	ret
moreRdBsy:
	in a,(CFstat)	; read CF status 
	and 80h		; mask off all except busy bit
	jr nz,readbsy1
	pop bc
	pop de
	ld a,(readbsysav)	;restore regA, but not status flags
	ret
; initialize for file load operation
initload:
	ld hl,0		; clear the high address in preparation for file load
	ld (addr3116),hl	; addr3116 modified with Intel Hex format 4 
	xor a		
	ld (fUpload),a	;assuming this is not a file in extended address format
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jp z,filesave
	cp 1		; end of file transfer?
	jp z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
; limit the memory size to 16 meg, so will ignore the highest byte of 32-bit address
; if upload flag, fUpload, is cleared (default), then bank 0 and bank 0x3F are for 0x0-0xFFFF
; if upload flag, fUpload, is not zero (with U command), then:
; bank 0 and bank 1 are for 0x0-0xFFFF
; bank 2 and bank 3 are for 0x10000-0x1FFFF
; bank 4 and bank 5 are for 0x20000-0x2FFFF
; bank 6 and bank 7 are for 0x30000-0x3FFFF
;   etc
; the formula is current bank = high byte x 2  
; if address is greater than 0x8000, it goes to current bank + 1

	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jp nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
;512K RAM in 32K areas.  Common area is at top $78000-$7FFFF
; bank area is 0x0 at power up, it can be $0-$77FFF, incrememnting 32K at a time
; so bank 1 is $08000, bank 2 is $10000, bank 3 is $18000, bank 14 is $70000
	ld a,(addr3116)	;calculate the current bank value
	sla a		;shift left one bit, 4 times
	sla a
	sla a
	sla a
;	ld (currbank),a	;Extended linear addr command will update the current bank variable
	out0 (BBR),a
	ld a,1
	ld (fUpload),a	;flag this file upload as extended addressing file

	ld a,'E'		; denote a successful Extended linear addr update
	jp filesav2
; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld hl,fileEnd$
	call strout

	xor a
	out0 (BBR),a	;point bank register to bank 0

	jp CMD
; the assumption is the data is good and will be saved to the destination memory
; if addr3116 and addr3116+1 are zero, then HL load normally
; if addr3116 and addr3116+1 are non zero, then HL lesser than 0x8000 loads to current bank
;  and HL greater than 0x8000 loads to current bank + 1

filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B

	ld a,(fUpload)	;decide how to save data based on upload flag
	or a
	jr z,filesavx	;upload flag is zero
	ld a,h		;test the high byte of HL register
	or a
	jp p,filesavx	;HL lesser than 0x8000
	and 7fh		;mask off the most significant bit of HL
	ld h,a
	in0 a,(BBR)	;get the current bank 
	push af		;save the current bank
	add 8		;increment to next bank for regHL 0x8000 or greater
	out0 (BBR),a
;	ld a,(currbank)	;increment the bank for HL 0x8000 or greater
;	inc a
;	out (bankReg),a	
	call filesav
	pop af		;restore the current bank
	out0 (BBR),a
;	ld a,(currbank)	;restore the current bank value to bank register
;	out (bankReg),a
	jp calchksum
filesav:
	call GETHEXQ	; get a byte
	ld (hl),a		; data to destination
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc hl		;
	dec d
	jr nz,filesav
	ret

;	ld ix,0c000h	; 0c000h is buffer for incoming data
filesavx:
	call GETHEXQ	; get a byte
;	ld (ix),a		; save to buffer
	ld (hl),a		;save data to destination
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
;	inc ix
	inc hl
	dec d
	jp nz,filesavx
calchksum:
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMA operation
;;;;;;;;;;;;;;;;;;;;;;;;;;;
	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jr nz,flushln
	jp fileload

testRAM:
; test memory from top of this program to 0xFFFE 
	ld hl,testram$	; print test ram message
	call strout
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld iy,(testseed)	; a prime number seed, another good prime number is 211
TRagain:
	ld hl,PROGEND	; start testing from the end of this program
	ld de,137		; increment by prime number
TRLOOP:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	inc hl
	ld (hl),b
	inc hl
	add iy,de		; add a prime number
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRLOOP	; continue until reaching 0xFFFE
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRLOOP
	ld hl,0b000h	; test memory from 0xAFFF down to 0x0000
TR1LOOP:
	push iy
	pop bc		; bounce off stack
	dec hl
	ld (hl),b		; write MSB
	dec hl
	ld (hl),c		; write LSB
	add iy,de		; add a prime number
	ld a,h		; check h=l=0
	or l
	jp nz,TR1LOOP
	ld hl,PROGEND	; verify starting from the end of this program
	ld iy,(testseed)	; starting seed value
TRVER:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jp nz,TRERROR
	inc hl
	ld a,(hl)		; get MSB
	cp b
	jp nz,TRERROR
	inc hl
	add iy,de		; next reference value
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRVER	; continue verifying til end of memory
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRVER
	ld hl,0b000h	; verify memory from 0xB000 down to 0x0000
TR1VER:
	push iy		; bounce off stack
	pop bc
	dec hl
	ld a,(hl)		; get MSB from memory
	cp b		; verify
	jp nz,TRERROR
	dec hl
	ld a,(hl)		; get LSB from memory
	cp c
	jp nz,TRERROR
	add iy,de
	ld a,h		; check h=l=0
	or l
	jp nz,TR1VER
	ld hl,ok$		;put out an 'OK' message
	call strout
	ld (testseed),iy	; save seed value

	call cstat
	jp z,TRagain	;no keyboard input, do another iteration of memory test
	call cin

	jp CMD
TRERROR:
	push hl		;save HL
	ld hl,RAMerr$
	call strout
	pop hl
;	call SPCOUT	; a space char to separate the 'r' command
;	ld a,'H'		; display content of HL reg
;	call COUT		; print the HL label
;	ld a,'L'
;	call COUT
;	call SPCOUT	
	call ADROUT	; output the content of HL 	
	jp CMD
; Read CF disk
; data buffer is at 0x1000
; previous data is at 0x2000 for comparison to current data
readCF:
	ld hl,read$	; put out read command message
	call strout
	ld hl,track$	; enter track in hex value
	call strout
	call GETHEX	; get a byte of hex value as track
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	ld (RDtrack),a	; save it 
	ld hl,sector$	; enter sector in hex value
	call strout
	call GETHEX	; get a byte of hex value as sector
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	ld (RDsector),a	; save it
READRD1:
	ld hl,1000h	; copy previous block to 2000h
	ld de,2000h
	ld bc,200h	; copy 512 bytes
	ldir		; block copy
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,0		; read first sector
	out (CF1623),a	; high byte of track is always 0
	ld a,(RDsector)	;Z80SBC get sector value
	out (CF07),a	; write sector
	ld a,(RDtrack)
	out (CF815),a
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
;readdrq:
;	in a,(CFstat)	; check data request bit set before read CF data
;	and 8		; bit 3 is DRQ, wait for it to set
;	jp z,readdrq
	call chkdrq	;check data request bit set before write CF data
	ld hl,1000h	; store CF data starting from 1000h
	ld c,CFdata	; reg C points to CF data reg
	ld b,0h		; sector has 256 16-bit data
	inir		;Z80SBC
	inir
dumpdata:
	ld d,32		; 32 lines of data
	ld hl,1000h	; display 512 bytes of data
dmpdata1:
	push hl		; save hl
	ld hl,CRLF$	; add a CRLF per line
	call strout
	pop hl		; hl is the next address to display
	call DMP16TS	; display 16 bytes per line
	dec d
	jr nz,dmpdata1

	ld hl,1000h	; compare with data block in 2000h
	ld bc,200h
	ld de,2000h
blkcmp:
	ld a,(de)		; get a byte from block in 2000h
	inc de
	cpi		; compare with corresponding data in 1000h
	jp po,blkcmp1	; exit at end of block compare
	jr z,blkcmp	; exit if data not compare
	ld hl,notsame$	; send out message that data not same as previous read
	call strout
	jr chkRDmore
blkcmp1:	
	ld hl,issame$	; send out message that data read is same as before
	call strout

chkRDmore:
	ld hl,0		;clear sector offset value
	ld (sectoff),hl
	ld hl,RDmore$	; carriage return for next sector of data
	call strout
	call tstCRLF	; look for CRLF
	jp nz,CMD		; 
	ld hl,(RDsector)	; load track & sector as 16-bit value
	inc hl		; increment by 1
	ld (RDsector),hl	; save updated values
	ld hl,track$	; print track & sector value
	call strout
	ld a,(RDtrack)
	call HEXOUT
	ld hl,sector$
	call strout
	ld a,(RDsector)
	call HEXOUT
	jp READRD1

chkdrq:
	in a,(CFstat)	; check data request bit set before write CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,chkdrq
	ret
; drive A directory is track 1, sectors 0-0x1F
; drive B directory is track 0x40, sectors 0-0x1F
; drive C directory is track 0x80, sectors 0-0x1F
; drive D directory is track 0xC0, sectors 0-0x1F
format:
	ld hl,clrdir$	; command message
	call strout
	call cin
	cp 'A'
	jr z,formatA	; fill track 1 sectors 0-0x1F with 0xE5
;	cp 'B'
;	jr z,formatB	; fill track 0x40 sectors 0-0x1F with 0xE5
;	cp 'C'
;	jr z,formatC	; fill track 0x80 sectors 0-0x1F with 0xE5
;	cp 'D'
;	jr z,formatD	; fill track 0xC0 sectors 0-0x1F with 0xE5
	jp abort		; abort command if not in the list of options
formatA:
	ld de,100h	; start with track 1 sector 0
;	jr doformat
;formatB:
;	ld de,4000h	; start with track 0x40 sector 0
;	jr doformat
;formatC:
;	ld de,8000h	; start with track 0x80 sector 0
;	jr doformat
;formatD:
;	ld de,0c000h	; start with track 0xC0 sector 0
;doformat:
	ld hl,confirm$	; confirm command execution
	call strout
	call tstCRLF
	jp nz,abort	; abort command if not CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; MSB track is 0
	ld a,d		; reg D contains the track info
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
	ld hl,0e5e5h	; value for empty directories
wrCFf:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,e		; write CPM sector
	cp 20h		; format sector 0-0x1F
	jp z,wrCFdonef	; done formatting
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	; check data request bit set before write CF data

	ld b,0h		; sector has 256 16-bit data
loopf:
	out (c),h		;z80 writes 2 bytes to CF
	out (c),h	
	inc b
	jp nz,loopf
	call readbsy	;wait on CF status busy bit

	inc e		; write next sector
	jp wrCFf
wrCFdonef:
	jp CMD

; boot CPM
; copy program from LA9-LA26 (9K) to 0xDC00
; jump to 0xF200 after copy is completed.
BootCPM:
	ld hl,bootcpm$	; print command message
	call strout
	call cin		; get input
;	cp '1'		; '1' is user apps
;	jp z,bootApps
;	cp '2'		; '2' is cpm2.2
;	jp z,boot22
;	cp '3'		; '3' is cpm3, not implemented
;	jp z,boot3
	cp '4'		;RomWBW
	jp z,bootwbwfile
	jp what
;boot3:
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a
;	xor a		; clear reg A
;	out (CF1623),a	; track 0
;	out (CF815),a
;	ld hl,1100h	; CPM3LDR starts from 0x1100
;	ld c,CFdata	; reg C points to CF data reg
;	ld d,1h		; read from LA 1 to LA 0x0f, 7K--much bigger than needed
;readCPM3:
;	ld a,1		; read 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; read CPM sector
;	cp 10h		; between LA1 and LA0fh
;	jp z,goCPM3	; done copying, execute CPM
;	out (CF07),a	; 
;	ld a,20h		; read sector command
;	out (CFstat),a	; issue the read sector command
;	call chkdrq	;check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	inir		;z80 read 256 bytes
;	inir		;z80 read 256 bytes

;	inc d		; read next sector
;	jp readCPM3
;goCPM3:
;	jp 01100h		; BIOS starting address of CP/M

;boot22:
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a
;	xor a		; clear reg A
;	out (CF1623),a	; track 0
;	out (CF815),a
;	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
;	ld c,CFdata	; reg C points to CF data reg
;	ld d,80h		; read from LA 0x80 to LA 0x92
;readCPM1:
;	ld a,1		; read 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; read CPM sector
;	cp 92h		; between LA80h and LA91h
;	jp z,goCPM	; done copying, execute CPM
;	out (CF07),a	; 
;	ld a,20h		; read sector command
;	out (CFstat),a	; issue the read sector command
;	call chkdrq	; check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	inir		;z80 read 256 bytes
;	inir		;z80 read 256 bytes

;	inc d		; read next sector
;	jp readCPM1
;goCPM:
;	jp 0f200h		; BIOS starting address of CP/M

;bootApps:
;restore user application from CF disk to 0x0-0xAFFF
;jump to 0 when done
;	ld hl,confirm$	; CRLF to execute the command
;	call strout
;	call tstCRLF
;	jp nz,abort	; abort command if no CRLF

;	xor a		; clear reg A
;	out (CF1623),a	; track 0
;	out (CF815),a
;	ld hl,0		; user apps starts from 0x0 to 0xAFFF
;	ld c,CFdata	; reg C points to CF data reg
;	ld d,11h		; read from LA 0x11 to LA 0x68
;readApps:
;	ld a,1		; read 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; read CPM sector
;	cp 69h		; between LA11h and LA68h
;	jp z,goApp	; done copying, execute CPM
;	out (CF07),a	; 
;	ld a,20h		; read sector command
;	out (CFstat),a	; issue the read sector command
;	call chkdrq	; check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	inir		;z80 read 256 bytes
;	inir		;z80 read 256 bytes

;	inc d		; read next sector
;	jp readApps
;goApp:
;	jp 0		; User apps starts from 0x0
bootwbwfile:
; for 1024-directory RomWBW, first 1meg of disk space is not used by CP/M,
;  so RomWBW image is stored within the 1st 1meg of disk space
;  RomWBW is 480K which leaves the top 32K untouched where monitor resides
; load 512K ROMWBW image stored in first file of first slice of CF disk
; it starts from track 01, sector 20 and ends at track 04 sector $df
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
bootWBWnow:
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	call readbsy
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call readbsy	;;8 wait until busy flag is cleared
;set up ix, iy pointers to memory move variables
	ld ix,fSecRange	;ix is flag for sector range
	ld iy,wbwbank	;iy is memory bank iy+1 is track number
;copy ends when top most bank (bank 15) is reached
	xor a
	ld (iy),a		;bank reg starts from 0
	ld a,01h		;RomWBW is stored in tracks 01, 02, 03, 04
	ld (iy+1),a

outerloopf:
	ld de,2060h	;start with sector 20 to sector 5f
	ld a,4
	ld (ix),a		;inner loop is 4
; the copy routine is awkward because it starts from sector 20 and overflow to sector 20 of 
;  next track.  So there is a special case of copying 16KB or 32 sectors ($e0-$FF) of one track and
;  and another 16KB or 32 sectors ($00-$1f) of next track
;  (ix) is sector range flag such that:
;    4, write 32KB to current track, sectors $60-$9f
;    3, write 32KB to current track, sectors $a0-$df
;    2, write 16KB to current track, sectors $e0-$ff
;    1, write 16KB to next track, sectors $0-$1f
innerloopf:
	ld a,(iy)		;get memory bank number
	cp 15		;the copy is completed when top-most bank is reached
	jp z,cpRomWBWdone
	sla a		;bank value is iy*8
	sla a
	sla a
	out0 (BBR),a
	inc (iy)
	ld hl,0		;memory location from 0-7FFF
	ld a,(iy+1)	;set track number
	call rdCF		;copy 32K to specified bank
	ld a,(ix)		;check inner loop count
	cp 4
	jr nz,inner2f
	ld de,60a0h	;set start/end sectors to 60/9f
inner2f:
	cp 3
	jr nz,inner1f
	ld de,0a0e0h	;set start/end sectors to a0/df
inner1f:
	cp 2
	jr nz,inner1zf
	ld de,0e000h	;set start/end sectors to e0/ff

inner1zf:
;special case for innerloop count of 1
;HL points to 0x4000
;do not change bankReg
;increment track
	cp 1
	jp nz,inner0f
	ld de,0020h	;set start/end sectors to 00/20 of next track
	inc (iy+1)	;increment the track number
	ld hl,4000h
	ld a,(iy+1)	;get track number
	call rdCF

inner0f:
	dec (ix)
	jp nz,innerloopf
; copy ends when top most bank (bank 15) is reached
	jp outerloopf
cpRomWBWdone:
	xor a
	out0 (BBR),a	;set memory bank to lowest 32K RAM
	jp 0		;jump to RomWBW which is address 0 of lowest bank
rdCF:
;this routine copies data as specified by track (regA) and start/end sectors (reg DE)
; into memory pointed by regHL
; hl specifies the starting address in memory
; de specifies the starting and end sectors
; Reg A specifies the track value
; bankReg already set up to correct 32K memory bank
	out (CF815),a	; track specified by reg A
	xor a
	out (CF1623),a
	ld c,CFdata	; reg C points to CF data reg
rdCF1:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp e		; reg E is the end sector value
	ret z		; done copying, 
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before read CF data
	ld b,0h		; sector has 512 8-bit data
	inir		;z80 read 256 bytes
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp rdCF1

; Write program to CF disk
;  allowable parameters are '0' for copying boot & Z1RCC monitor
copyCF:
	ld hl,copycf$	; print copy message
	call strout
	call cin		; get write parameters
	cp '0'
	jp z,cpbootZ1mon	;copy boot & Z1RCC monitor
	cp '4'		; save RomWBW
	jp z,SaveRomWBW
;	cp '1'
;	jp z,cpApps
;	cp '2'
;	jp z,CopyCPM2
;	cp '3'
;	jp z,CopyCPM3
	jp what		; error, abort command
	jp CMD
cpbootZ1mon:
;copy boot program to master boot record
;copy Z1RCC monitor to track 0 sector $f8-$ff
	ld hl,confirm$	; carriage return to execute the program
	call strout
	call tstCRLF
	jp nz,CMD		; abort command if not CR or LF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		;set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		;set feature command
	out (CFstat),a	
	call readbsy	;wait until busy flag is cleared
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	ld d,0f8h		;monitor is stored in sectors $F8 to $FF
	ld hl,0b000h	;points to beginning of the monitor
	ld c,CFdata
wmoresect:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
	cp 0		; read sectors 0xF8-0xFF
	jp z,cpbootMon	; modify the master boot sector
	out (CF07),a	; read the sector pointed by reg D		

	ld a,30h		; write sector command
	out (CFstat),a	; issue the read sector command
	call readdrq
	ld b,0h		; sector has 512 8-bit data
	otir
	otir
	call readbsy	;wait for write to finish
	inc d
	jp wmoresect
cpbootMon:
; modify the boot sector so it will boot Z1RCC Monitor after reset
;this is the program that copies the CFbootloader into CF disk at master boot record
;read the master boot record to a buffer area (0xc000-0xc1ff)
;  write the CFbootloader so each byte is copied twice
;  write the modified 512 bytes back out to master boot record
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	out (CF07),a	;master boot block
	ld b,a
	inc a
	out (CFsectcnt),a	;read 1 sector
	ld hl,0c000h	;buffer for existing master boot block data
	ld c,CFdata	;point to CF data register
	ld a,20h		;read command
	out (CFstat),a
	call readdrq
	inir		;fill the buffer with existing master boot record data
	ld b,CFbootldrEnd-CFbootldr	;number of bytes to write to buffer
	ld hl,CFbootldr	;point to source
	ld de,0c000h	;point to destination
cpCFbootldr:
	ld a,(hl)		;get data from source
	ld (de),a		;write to destination twice
	inc de
	ld (de),a
	inc de
	inc hl
	dec b		
	jr nz,cpCFbootldr
	
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	out (CF07),a	;master boot block
	ld b,a		;initialize regB for otir instruction
	inc a
	out (CFsectcnt),a	;write 1 sector
	ld hl,0c000h	;point to the updated buffer
;	ld c,CFdata	;point to CF data register.  Note regC is already initialized
	ld a,30h		;write command
	out (CFstat),a
	call readdrq	;wait for DRQ to set
	otir		;write CFbootldr program to master boot record
	otir
	call readbsy	;wait for write to finish
	jp CMD		;go back to monitor through help which set feature to 8-bit mode

readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq
	ret

CFbootldr:
;program in master boot record will be loaded here to copy Z1RCC monitor $b000-$bfff
;Z180 I/O registers are already mapped to 0xC0
	ld a,80h		;page out the ROM in CPLD
	out (1fh),a	;bit 7 of bank select pages out ROM
	ld a,0b0h		;common area is 0xb000-0xffff
	out0 (CBAR),a	;set common/bank register so $0-$afff is bank,
			;  and $b000-$ffff is common
	ld a,70h
	out0 (CBR),a	;set common base to $70000, so common area $b000-$ffff is
			;  mapped to physical memory $7b000-$7ffff
	ld a,0e0h		;set up LBA mode
	out (CF2427),a	
	ld a,1		; set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		; set feature command
	out (CFstat),a	
readbsyb:
	in a,(CFstat)	; check bsy flag first
	and 80h		; bsy flag is at bit 7
	jr nz,readbsyb

	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a

	ld d,0f8h		; points to sector to read, last 8 sectors (4KB) in track 0
	ld hl,0b000h	; store CF data starting from 0b000h
	ld c,CFdata	; reg C points to CF data reg
moresectb:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
	cp 0		; read sectors 0xF8-0xFF
	jp z,0b400h	; load completed, run program loaded at 0xB400

	out (CF07),a	; read the sector pointed by reg D		

	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
readdrqb:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,readdrqb

	ld b,0h		; sector has 512 8-bit data
	inir
	inir

	inc d
	jr moresectb
	nop
CFbootldrEnd:
SaveRomWBW:
;copy RomWBW that's currently loaded in 480K of memory to CF disk starting from
;  track 1, sector 20
	ld hl,confirm$	; carriage return to execute the program
	call strout
	call tstCRLF
	jp nz,CMD		; abort command if not CR or LF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	call readbsy
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call readbsy	;;8 wait until busy flag is cleared
;set up ix, iy pointers to memory move variables
	ld ix,fSecRange	;ix is flag for sector range
	ld iy,wbwbank	;iy is memory bank iy+1 is track number
;The copy ends when top most bank (bank 15) is reached
	xor a
	ld (iy),a		;bank reg starts from 0
	ld a,01h		;RomWBW is stored in tracks 01, 02, 03, 04
	ld (iy+1),a

SaveLoop:
	ld de,2060h	;start with sector 20 to sector 5f
	ld a,4
	ld (ix),a		;inner loop is 4
; the copy routine is awkward because it starts from sector 20 and overflow to sector 20 of 
;  next track.  So there is a special case of copying 16KB or 32 sectors ($e0-$FF) of one track and
;  and another 16KB or 32 sectors ($00-$1f) of next track
;  (ix) is sector range flag such that:
;    4, write 32KB to current track, sectors $60-$9f
;    3, write 32KB to current track, sectors $a0-$df
;    2, write 16KB to current track, sectors $e0-$ff
;    1, write 16KB to next track, sectors $0-$1f
SaveInnerLoop:
	ld a,(iy)		;get memory bank number
	cp 15		;the copy is completed when top-most bank is reached
	jp z,SaveRomWBWdone
	sla a		;bank value is iy*8
	sla a
	sla a
	out0 (BBR),a
	inc (iy)
	ld hl,0		;memory location from 0-7FFF
	ld a,(iy+1)	;set track number
	call wrCF		;copy 32K from specified bank to specified CF tract/sector
	ld a,(ix)		;check inner loop count
	cp 4
	jr nz,SvInner2
	ld de,60a0h	;set start/end sectors to 60/9f
SvInner2:
	cp 3
	jr nz,SvInner1
	ld de,0a0e0h	;set start/end sectors to a0/df
SvInner1:
	cp 2
	jr nz,SvInner1z
	ld de,0e000h	;set start/end sectors to e0/ff

SvInner1z:
;special case for innerloop count of 1
;HL points to 0x4000
;do not change bankReg
;increment track
	cp 1
	jp nz,SvInner0
	ld de,0020h	;set start/end sectors to 00/20 of next track
	inc (iy+1)	;increment the track number
	ld hl,4000h
	ld a,(iy+1)	;get track number
	call wrCF
SvInner0:
	dec (ix)
	jp nz,SaveInnerLoop
	jp SaveLoop
SaveRomWBWdone:
	xor a
	out0 (BBR),a	;set memory bank to lowest 32K RAM
	jp CMD		;return to command processing
wrCF:
;this routine writes memory pointed by regHL into CF disk
; as specified by track (regA) and start/end sectors (reg DE)
; hl specifies the starting address in memory
; de specifies the starting and end sectors
; Reg A specifies the track value
; bankReg already set up to correct 32K memory bank
	out (CF815),a	; track specified by reg A
	xor a
	out (CF1623),a
	ld c,CFdata	; reg C points to CF data reg
wrCF1:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp e		; reg E is the end sector value
	ret z		; done saving, 
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 512 8-bit data
	otir		;z80 writes 256 bytes
	otir		;z80 writes 256 bytes
	call readbsy	;wait for writes to complete
	inc d		; write next sector
	jp wrCF1

; write CPM to CF
; write data from 0xDC00 to 0xFFFF to CF LA128-LA146 (9K)
;CopyCPM2:
;	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
;	ld de,8092h	; reg DE contains beginning sector and end sector values
;	jp wrCF
;CopyCPM3:
;	ld hl,1100h	; CPMLDR starts from 0x1100
;	ld de,0110h	; reg DE contains beginning sector and end sector values
;	jp wrCF
;cpApps:
; copy the memory contents below 0xB000 to CF flash
;	ld hl,0		;start from 0x0
;	ld de,1168h	;sectors 11 to sector 68
;	jp wrCF

;wrCF:
;	push hl		; save value
;	ld hl,confirm$	; carriage return to execute the program
;	call strout
;	pop hl
;	call tstCRLF
;	jp nz,CMD		; abort command if not CR or LF
;	ld a,0e0h		; set Logical Address addressing mode
;	out (CF2427),a
;	xor a		; clear reg A
;	out (CF1623),a	; track 0
;	out (CF815),a
;	ld c,CFdata	; reg C points to CF data reg
;wrCF1:
;	ld a,1		; write 1 sector
;	out (CFsectcnt),a	; write to sector count with 1
;	ld a,d		; write CPM sector
;	cp e		; reg E contains end sector value
;	jp z,wrCFdone	; done copying, execute CPM
;	out (CF07),a	; 
;	ld a,30h		; write sector command
;	out (CFstat),a	; issue the write sector command
;	call chkdrq	; check data request bit set before write CF data
;	ld b,0h		; sector has 256 16-bit data
;	otir		;z80 write 256 bytes
;	otir		;z80 wrute 256 bytes

;	call readbsy	;wait until busy flag is cleared
;
;	inc d		; write next sector
;	jp wrCF1
;wrCFdone:
;	jp CMD
	

INPORT:
; read data from specified I/O port in page 0
; command format is "I port#"
; 
	ld hl,inport$	; print command 'I' prompt
	call strout
	call GETHEX	; get port # into reg A
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	ld c,a		;load port # in C
	ld b,0		;read from page 0
	in a,(c)		; get data from port # 
	push af
	ld hl,invalue$
	call strout
	pop af
	call HEXOUT
	jp CMD
OUTPORT:
; write data to specified I/O port in page 0
; command format is "O value port#"
	ld hl,outport$	; print command 'O' prompt
	call strout
	call GETHEX	; get value to be output
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	push af
	ld hl,outport2$	; print additional prompt for command 'O'
	call strout
	call GETHEX	; get port number into reg A
	jp c,OUTPORT9		;abort for non-hexdecimal input
	jp z,OUTPORT9
	ld c,a
	ld b,0		;write to page 0
	pop af
	out (c),a		; output data in regB to port in reg C
	jp CMD
OUTPORT9:
	pop af
	jp CMD
LISTHEX:
; list memory as Intel Hex format
; the purpose of command is to save memory as Intel Hex format to console
	ld hl,listhex$	; print command 'L' prompt
	call strout
	call ADRIN	; get address word into reg DE
	jp z,CMD		;return to command prompt if illegal input
	push de		; save for later use
	ld hl,listhex1$	; print second part of 'L' command prompt
	call strout
	call ADRIN	; get end address into reg DE
	jp z,CMD		;return to command prompt if illegal input
listhex1:
	ld hl,CRLF$	; put out a CR, LF	
	call strout
	ld c,10h		; each line contains 16 bytes
	ld b,c		; reg B is the running checksum
	ld a,':'		; start of Intel Hex record
	call cout
	ld a,c		; byte count
	call HEXOUT
	pop hl		; start address in HL
	call ADROUT	; output start address
	ld a,b		; get the checksum
	add a,h		; accumulate checksum
	add a,l		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	xor a		
	call HEXOUT	; record type is 00 (data)
listhex2:
	ld a,(hl)		; get memory pointed by hl
	call HEXOUT	; output the memory value in hex
	ld a,(hl)		; get memory again
	add a,b		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	inc hl
	dec c
	jp nz,listhex2
	ld a,b		; get the checksum
	neg a
	call HEXOUT	; output the checksum
; output 16 memory location, check if reached the end address (saved in reg DE)
; unsign compare: if reg A < reg N, C flag set, if reg A > reg N, C flag clear
	push hl		; save current address pointer
	ld a,h		; get MSB of current address
	cp d		; reg DE contain the end address
	jp nc,hexend	; if greater, output end-of-file record
	jp c,listhex1	; if less, output more record
; if equal, compare the LSB value of the current address pointer
	ld a,l		; now compare the LSB of current address
	cp e
	jp c,listhex1	; if less, output another line of Intel Hex
hexend:
; end-of-record is :00000001FF
	ld hl,hexEnd$
	call strout
	pop hl		; clear up the stack

	jp CMD
;Get an address and jump to it
go:
	ld hl,go$		; print go command message
	call strout
        	CALL ADRIN
	jp z,CMD		;abort command with illegal input
        	LD H,D
        	LD L,E
	push hl		; save go address
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	pop hl
	jp nz,abort
	jp (hl)		; jump to address if CRLF

; fill memory from 0x8000 0xFFFF with zero or 0xFF

fillZ:
	ld hl,fill0$	; print fill memory with 0 message
	call strout
	ld b,0		; fill memory with 0
	jr dofill
fillF:
	ld hl,fillf$	; print fill memory with F message
	call strout
	ld b,0ffh		; fill memory with ff
dofill:
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld hl,PROGEND	; start from 0x8000
	ld a,0ffh		; end address in reg A
filla:
	ld (hl),b		; write memory location
	inc hl
	cp h		; reached 0xFF00?
	jr nz,filla	; continue til done
	cp l		; reached 0xFFFF?
	jr nz,filla
	ld hl,0b000h	; fill value from 0xB000 down to 0x0000
fillb:
	dec hl
	ld (hl),b		; write memory location with desired value
	ld a,h		; do until h=l=0
	or l
	jr nz,fillb
	jp CMD

; print help message
help:
	ld hl,help$	; print help message
	call strout
	jp CMD

;base on utilities from Glitch Work v0.1, (C) 2012 Jonathan Chapman, heavily modified
;Edit memory from a starting address until X or x is
;pressed. Display mem loc, contents, and results
EDMEM:  	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
        	LD H,D
        	LD L,E
EDMEM1:
	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	CALL SPCOUT
        	CALL DMPLOC
        	CALL SPCOUT
        	CALL GETHEX
       	jp c,CMD		;abort for illegal input
	jp z,EDMEM2	;handle CR, -, x
        	JP C,CMD
        	LD (HL),A
        	CALL SPCOUT
        	CALL DMPLOC
        	INC HL
        	JP EDMEM1
EDMEM2:
;handle non-hexdecimal input of CR, -, x or X
	cp '-'		;go to previous location
	jp nz,EDMEM3
	dec hl
	jp EDMEM1
EDMEM3:
	cp 0dh		;go to next location
	jp nz,CMD		;abort command for all other non-hex input
	inc hl
	jp EDMEM1

;Dump memory between two address locations
MEMDMP: 	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
        	LD H,D
        	LD L,E
        	LD C,10h
        	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
MD1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL DMP16
        	LD A,D
        	CP H
        	JP M,CMD
        	LD A,E
        	CP L
        	JP M,MD2
        	JP MD1
MD2:    	LD A,D
        	CP H
        	JP NZ,MD1
        	JP CMD

DMP16TS:
; dump memory pointed by HL, 
; print offset from the given track & sector values
;  as the address field
	push hl		; save reg
	ld a,'+'		;print offset symbol
	call cout
	ld hl,(sectoff)	;get offset from track&sector base
	call ADROUT	; output A23..A8
	push bc		;save reg
	ld bc,10h		;add 16 to offset
	add hl,bc
	pop bc
	ld (sectoff),hl	;save it
	pop hl		; restore reg
	jp DMP16D		; display the 16 data field

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMP16 -- Dump 16 consecutive memory locations
;
;pre: HL pair contains starting memory address
;post: memory from HL to HL + 16 printed
;post: HL incremented to HL + 16
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMP16:  	CALL ADROUT
DMP16D:			; 16 consecutive data
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	LD C,10h
	push hl		; save location for later use
DM1:    	CALL SPCOUT
        	CALL DMPLOC
        	INC HL		
        	DEC C
	jp nz,DM1

; display the ASCII equivalent of the hex values
	pop hl		; retrieve the saved location
	ld c,10h		; print 16 characters
	call SPCOUT	; insert two space
	call SPCOUT	; 
dm2:
	ld a,(hl)		; read the memory location
	cp ' '
	jp m,printdot	; if lesser than 0x20, print a dot
	cp 7fh
	jp m,printchar
printdot:
; for value lesser than 0x20 or 0x7f and greater, print '.'
	ld a,'.'
printchar:
; output printable character
	call cout
	inc hl
	dec c
	ret z
	jp dm2

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMPLOC -- Print a byte at HL to console
;
;pre: HL pair contains address of byte
;post: byte at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMPLOC: 	LD A,(HL)
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXOUT -- Output byte to console as hex
;
;pre: A register contains byte to be output
;post: byte is output to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXOUT: 	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	POP BC
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXASC -- Convert nybble to ASCII char
;
;pre: A register contains nybble
;post: A register contains ASCII char
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXASC: 	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADROUT -- Print an address to the console
;
;pre: HL pair contains address to print
;post: HL printed to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADROUT: 	LD A,H
        	CALL HEXOUT
        	LD A,L
        	CALL HEXOUT
        	RET

; if illegal character, command aborted
; if CR or space lesser than 4 characters entered, fill the missing with leading zeros
; if backspace, move cursor back and delete last character entered
; if -, go back one memory location
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADRIN -- Get up to 4 bytes address from console in reg DE
; if illegal address, set Z flag
;post: DE contains address from console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADRIN:
	ld de,0		
	call cin
	call ASCHEX	;get a hex value
; none hex value will end command
	jr z,exit0
	ld e,a		;save
backup1:		
	call cin
	cp 8		;backspace?
	jr z,ADRIN	;start over
  	call ASCHEX
;possible options here are 
; backspace
; space to advance command
; other none hex to terminate command
	jr z,exit123
	sla e
	sla e
	sla e
	sla e
	or e
	ld e,a		;save to reg E
getChar3:
	call cin
	cp 8
	jr z,backupE
	call ASCHEX
	jr z,exit123
	call addChar
	call cin
	cp 8
	jr z,delChar
	call ASCHEX
	jr z,exit123	;exit with 3 characters entered
	call addChar
	cp 0ffh		;regA is never 0xff so clear Z flag
	ret
backupE:
;shift regE back a nibble
	srl e
	srl e
	srl e
	srl e
	jr backup1
delChar:
;shift DE back a nibble
	sra d
	rr e
	sra d
	rr e
	sra d
	rr e
	sra d
	rr e
	ld d,0
	jr getChar3
addChar:
;shift DE forward a nibble and add reg A
	sla e
	rl d
	sla e
	rl d
	sla e
	rl d
	sla e
	rl d
	or e
	ld e,a
	ret
exit123
;if space or CR, return with Z flag cleared and valid data in DE
	cp ' '
	jr z,exitGood
	cp 0dh
	jr z,exitGood
exit0:
	xor a		;set Z flag
	ret
exitGood:
	or a		;regA is either space or CR, so this will clear Z flag
	ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;; 
;Get hex in regA
; set C flag to abort the operation <-expect calling routine to chk C flag first
; set Z flag to signal different action for calling routine:
;  x terminate command
;  - go back to previous memory location
;  CR next memory location
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GETHEX0:
	call cout		;echo back
	pop de		;start over but first undo the regDE push
GETHEX:
        	CALL cin
        	CALL ASCHEX
;valid first character are:
; hexdecimal value
;  CR,x,-  to be handled by calling routine
;  
	ret z		;not valid hex
	push de
        	LD D,A		;save to combine with 2nd input
        	CALL cinq		;don't automatic echo back on 2nd character
			;supress echo back of CR
;valid second character are:
; hexdecimal value,
; CR: one digit input
; BS: go back to beginning
; otherwise abort the command using C flag for signalling
	cp 8		;back space?
	jr z,GETHEX0	;start over
	cp 0dh		;no echo back for CR
	jr nz,GE0
	or a		;clear Z flag
	ld a,d
	pop de
	ret
GE0:
	call cout		;echo back
	call ASCHEX
	jp z,GE2
	sla d		;shift first hex input to high nibble
	sla d
	sla d
	sla d
        	or d		;combine with 2nd hex input
			;this operation may set Z flag is result is 0
	ld d,1		;take care of the case when result is 0 and Z flag set
	inc d		;this will clear the Z flag
GE1:    	pop de
        	ret
GE2:    	scf
        	pop de
	ret


; get hex without echo back
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;return condition Z set if not 0-9, A-F
; original value in regA returned if not hexdecimal character
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX:
	sub 30h		;ascii 0 is 0x30
	jp m,illegalx
	cp 0ah		;0-9?
	ret m
	sub 11h		;ascii A is 0x41
	jp m,illegaly
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;A-F?
	ret m
	sub 2ah		;ascii a is 0x61
	jp m,illegalz
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;a-f?
	ret m
illegalz
	add 20h-0ah	;return reg A to original value
illegaly
	add 11h
illegalx
	add 30h
	cp a		;set Z flag
	ret		;return with original regA and Z flag set

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GOBYT -- Push a two-byte instruction and RET
;         and jump to it
;
;pre: B register contains operand
;pre: C register contains opcode
;post: code executed, returns to caller
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GOBYT:  	LD HL,0000
        	ADD HL,SP
        	DEC HL
        	LD (HL),0C9h
        	DEC HL
        	LD (HL),B
        	DEC HL
        	LD (HL),C
        	JP (HL)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;SPCOUT -- Print a space to the console
;
;pre: none
;post: 0x20 printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
SPCOUT: 	LD A,' '
        	CALL cout
        	RET

; test for CR or LF.  Echo back. return 0
tstCRLF:
	call cin		; get a character					
	cp 0dh		; if carriage return, output LF
	jp z,tstCRLF1
	cp 0ah		; if line feed, output CR 
	jp z,tstCRLF2
	ret
tstCRLF1:
	ld a,0ah		; put out a LF
	call cout
	xor a		; set Z flag
	ret
tstCRLF2:
	ld a,0dh		; put out a CR
	call cout
	xor a		; set Z flag
	ret


strout:
;output null-terminated string
	ld a,(hl)
	or a
	ret z
	call cout
	inc hl
	jr strout
cout:
;output char in regA
	push af
chkEmpty:
	in0 a,(RxStat)		;read status
	and 2
	jr z,chkEmpty
	pop af
	out0 (TxData),a
	ret
cstat:
;check console input status, return 0 with Z set if no character available
	in0 a,(RxStat)		;read chan 0 status
	and 80h		;check receive data full
	ret
;
cin:
;return input character in regA
	in0 a,(RxStat)		;read status
	and 80h		;check receive data full
	jr z,cin
	in0 a,(RxData)		;get character in regA
	out0 (0c6h),a	;echo
	ret
cinq:
;return input character in regA
;no echo back
	in0 a,(RxStat)		;read status
	and 80h		;check receive data full
	jr z,cinq
	in0 a,(RxData)		;get character in regA
	ret

	org 0b000h
signon$:	db 10,13,"Z1RCC Monitor ver 0.2a 10/23/23",10,13,0
NoCF$:	db 13,10,"no CF disk",13,10,0
prompt$:	db 13, 10, 10, ">", 0
what$:   	db 13, 10, "?", 0
fileEnd$	db "X"
CRLF$	db 13,10,0
confirm$	db " press Return to execute command",0
abort$	db 13,10,"command aborted",0
notdone$	db 13,10,"command not implemented",0
go$	db "o to address: 0x",0
track$	db " track:0x",0
sector$	db " sector:0x",0
read$	db "ead CF disk",0
RDmore$	db 10,13,"Return for next sector, any other key for command prompt",10,13,0
notsame$	db 10,13,"Data NOT same as previous read",10,13,0
issame$	db 10,13,"Data same as previous read",10,13,0
inport$	db "nput from port ",0
invalue$	db 10,13,"Value=",0
outport$	db "utput ",0
outport2$	db " to port ",0
listhex$	db "ist memory as Intel Hex, start address=",0
listhex1$	db " end address=",0
hexEnd$	db 10,13,":00000001FF",10,13,0
fillf$	db "ill memory with 0xFF",10,13,0
fill0$	db "ero memory",10,13,0
testram$	db "est memory",10,13,0
ok$	db " OK",0
RAMerr$	db " HL: ",0
copycf$	db "opy to CF disk",10,13
;	db "0--boot,",10,13
;	db "1--User Apps,",10,13
;	db "2--CP/M2.2:",10,13
;	db "3--CP/M3: ",0
	db "0--boot & Z1RCC Monitor",10,13
	db "4--ROMWBW: "
	db 0
clrdir$	db " clear disk directories",10,13
	db "A -- drive A,",10,13
;	db "B -- drive B:",10,13
;	db "C -- drive C,",10,13
;	db "D -- drive D,",10,13	
;	db "E -- RAM drive: ",0
	db 0
bootcpm$	db "oot CP/M",10,13
;	db "1--User Apps,",10,13
;	db "2--CP/M2.2:",10,13
;	db "3--CP/M3: ",0
	db "4--RomWBW: "
	db 0

help$	db "elp",13,10
	db "G <addr> CR",13,10
	db "R <track> <sector>",13,10
	db "D <start addr> <end addr>",13,10
	db "I <port>",13,10
	db "O <value> <port>",13,10
	db "L <start addr> <end addr>",13,10
	db "Z CR",13,10
	db "F CR",13,10
	db "T CR",13,10
	db "E <addr>",13,10
	db "X <options> CR",13,10
	db "B <options> CR",13,10
	db "C <options> CR",0

PROGEND	equ 0c000h	;mark the end of program at 0xC000

	end
